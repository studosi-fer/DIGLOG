Prilo�eni su screenshotovi sklopova i VHDL kodovi istih.
Zasad se ne trebate mucit oko tih kodova (to vas ceka sljedeci labos), ali ako netko to ku�i, neka se slobodno poslu�i time
ako mu se ne da crtati sklopove.

Ne zaboravite koristiti ime u ENTITY i tim stvarima isto koje odaberete za ime sklopa, inace nece raditi.
