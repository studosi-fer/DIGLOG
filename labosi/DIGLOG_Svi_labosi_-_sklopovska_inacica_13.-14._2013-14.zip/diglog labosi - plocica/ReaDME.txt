neke pripreme nisam stavio zato sto su vezane za moj jmbag, 
za greske ne odgovaram i ne prepisujte doslovno nego vidite jesu li stvari vezane za JMBAG ili ne, 
i naucite sto kodovi rade inace nema smisla dolaziti

ujprog.exe se stavlja u root windows foldera, za ostale OS procitajte upute(skinite i novu verziju ako postoji posto ove prilozene nece mozda biti aktualne)