#include <stdio.h>
#include <math.h>
#include <string.h>

/* (c) wex */
/* PRVI (uspješni) pokušaj realizacije hammingova koda u C-u i račun sindroma; znanje: par tjedana pipija */
/* Komentar: ovaj kod je kranje neoptimiziran i nečitljiv, ali radi... Moglo se sve napraviti bez kopiranja koda samo s par if-ova ili funkcija ali whatever */


int main(void) {
	int choice;
	char code[1001]; 
	int enc[1011][11]; 
	int p[10] = {0}; 
	int s[10][3]; 
	int greska;
	int par; 
	int k, n, r; 
	int a, b, c, d, e, sa, ost;
	char nastavak;
	
	printf("-- (c) wex --\n");
	for (a=0; a<10; a++)
		p[a]=pow(2,a);
	do {
		for (a=0; a<1011; a++) {
			if (a<1001) code[a] = 0;
			for (b=0; b<11; b++) 
				enc[a][b] = 0;
		}
		for (a=0; a<10; a++)
			for (b=0; b<3; b++) 
				s[a][b] = 0;
		greska = 0;
		k = 0; n = 0; r = 0;
		a = 0; b = 0; c = 0; d = 0; e = 0; sa = 0; ost = 0;
		printf("Odaberite radnju:\n-izracun hammingove kodne rijeci (upisite 1)\n-izracun sindroma i pronalazak pogreske (upisite 2)\n");
		scanf(" %d", &choice);
		if (choice==1) {
				printf("Upisi 0 za parni, 1 za neparni paritet: ");
				scanf(" %d", &par);
				printf("Upisite kodnu rijec: ");
				scanf(" %1000[^\n]", code);
				k = strlen(code);
				for (a=0; a<10; a++)
					if (pow(2,a+1)>= k + a + 2) { 
						r = a + 1;
						a = 10;
					}
				printf("Duljina rijeci i broj zastitnih bitova: %d %d", k, r);
				for (a=0; a<k; a++) {
					enc[a+r][0] = code[a] - 48;
				}
				d = r; 
				for (a=r+k-1; a>=0; a--) { 
					for (b=0; b<r; b++) {
						if (a==p[b]-1) { 
							d = d - 1;
							for (c=d; c<a; c++) {
								enc[c][0] = enc[c+1][0];
							}
							enc[a][0] = 2;
						}
					}
				}
				printf("\n");
				for (a=0; a<k+r; a++) {
					c = a + 1;
					for (b=10; b>0; b--) {
						ost = c % 2;
						c = c / 2;
						enc[a][b] = ost;
						if (ost==0 && c==0) b = 0;
					}
				}
				d = 0;
				for (a=0; a<k+r; a++) {
					if (enc[a][0] == 2) {
						for (b=1; b<11; b++) {
							if (enc[a][b] == 1) {
								for (c = a + 1; c<k+r; c++) {
									if (enc[c][b] == 1) d = d + enc[c][0];
								}
							}
						}
						if (par == 0) enc[a][0] = d % 2;
						if (par == 1) {
							if (d%2 == 0) enc[a][0] = 1;
							else enc[a][0] = 0;
						}
						d = 0;
					}
				}
				printf("Konacan rezultat: ");
				for (a=0; a<k+r; a++) printf("%d", enc[a][0]);
				printf("\n");
		} else if (choice==2) {
			printf("Upisite kodnu rijec koju zelite provjeriti: ");
			scanf(" %1000[^\n]", code);
			printf("Upisite koji je paritet koristen, 1 za neparni, 0 za parni: ");
			scanf(" %d", &par);
			n = strlen(code);
			for (a=0; a<n; a++) {
				enc[a][0] = code[a] - 48;
				c = a + 1;
				for (b=10; b>0; b--) {
					ost = c % 2;
					c = c / 2;
					enc[a][b] = ost;
					if (ost==0 && c==0) b = 0;
				}
			}
			for (a=0; a<n; a++) {
				for (e=0; e<10; e++) {
					if (a + 1 == p[e]) {
						s[sa][1] = enc[a][0];
						for (b=1; b<11; b++) {
							if (enc[a][b] == 1) {
								for (c = a + 1; c<n; c++) {
									if (enc[c][b] == 1) d = d + enc[c][0];
								}
							}
						}
						if (par == 0) {
							s[sa][0] = d % 2;
						}
						if (par == 1) {
							if (d%2 == 0) {
								s[sa][0] = 1;
							} else {
								s[sa][0] = 0;
							}
						}
						sa = sa + 1;
						d = 0; 
					}
				}
			}
			for (a=0; a<sa; a++) {
				if (s[a][0] + s[a][1] == 1) {
					s[a][2] = 1;
				}
			}
			for (a=0; a<sa; a++) {
				if (s[a][2] == 1) {
					greska = greska + pow(2, a);
				}
			}
			d = greska - 1;
			if (greska != 0) {
				printf("Greska je na %d. poziciji!\n", greska);
				if (enc[d][0] == 0) {
					enc[d][0] = 1;
				} else {
					enc[d][0] = 0;
				}
				printf("%s - unesena kodna rijec\n", code);
				for (a=0; a<n; a++) {
					printf("%d", enc[a][0]);
				} 
				printf(" - korigirana kodna rijec (pod uvjetom da se dogodila samo 1 greska)\n");
			} else printf("Nema greske!\n");
		} else printf("Neispravan unos.");
		printf("Nastaviti (y/n)? ");
		scanf(" %c", &nastavak);
	} while (nastavak=='Y' || nastavak=='y');
	
	return 0;
}